
	<section class="help" id="help">
		<div class="help__container container">
			<p><b>допомогти</b> просто!</p>
			<a href="<?php echo get_home_url(); ?>/platizhka/" class="btn">Долучитись</a>
			<div class="help__img help__img--one">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/1--active.jpg" alt="" class="help__active">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/mision--one-before.jpg" alt="" class="help__active-no">
			</div>
			<div class="help__img help__img--two">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/2--active.jpg" alt="" class="help__active">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/mision--before.jpg" alt="" class="help__active-no">
			</div>
			<div class="help__img help__img--three">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/3--active.jpg" alt="" class="help__active">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/3.jpg" alt="" class="help__active-no">
			</div>
			<div class="help__img help__img--four">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/4--active.jpg" alt="" class="help__active">
				<img src="<?php echo get_template_directory_uri(); ?>/assets/img/4.jpg" alt="" class="help__active-no">
			</div>
		</div>
	</section>