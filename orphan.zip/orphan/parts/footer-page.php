
	<footer class="footer">
		<div class="footer__container container">
			<p>© Orphan Education Club 2019, Всі права захищені</p>
			<ul>
				<li><a href="<?php echo get_home_url(); ?>#content">Про нас</a></li>
				<li><a href="<?php echo get_home_url(); ?>#mision">Наша місія</a></li>
				<li><a href="<?php echo get_home_url(); ?>#sos">SOS</a></li>
				<li><a href="<?php echo get_home_url(); ?>#progect">Проекти фонду</a></li>
				<li><a href="<?php echo get_home_url(); ?>#realized">Реалізовані проекти</a></li>
				<li><a href="<?php echo get_home_url(); ?>#team">Наша команда</a></li>
			</ul>
		</div>
	</footer>

