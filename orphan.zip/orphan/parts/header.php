
	<header class="header">
		<div class="container">
			<div class="header__container">

				<button class="hamburger" type="button">
					<span class="hamburger__box">
						<span class="hamburger__item"></span>
					</span>
				</button>
				
				<a href="<?php echo get_home_url(); ?>/platizhka/">Долучитись!</a>

			</div>
		</div>
	</header>
