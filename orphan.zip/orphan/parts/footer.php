
	<footer class="footer">
		<div class="footer__container container">
			<p>© Orphan Education Club 2019, Всі права захищені</p>
			<ul>
				<li class="more"><a href="#content">Про нас</a></li>
				<li class="more"><a href="#mision">Наша місія</a></li>
				<li class="more"><a href="#sos">SOS</a></li>
				<li class="more"><a href="#progect">Проекти фонду</a></li>
				<li class="more"><a href="#realized">Реалізовані проекти</a></li>
				<li class="more"><a href="#team">Наша команда</a></li>
			</ul>
		</div>
	</footer>

